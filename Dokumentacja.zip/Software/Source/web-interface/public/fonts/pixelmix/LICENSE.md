﻿The font file in this archive was created by Andrew Tyler www.AndrewTyler.net and font@andrewtyler.net
﻿--
You are free:

to Share — to copy, distribute and transmit the work
Under the following conditions:

Attribution — You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
Noncommercial — You may not use this work for commercial purposes.
No Derivative Works — You may not alter, transform, or build upon this work.

--

http://creativecommons.org/licenses/by-nc-nd/3.0/us/

--
