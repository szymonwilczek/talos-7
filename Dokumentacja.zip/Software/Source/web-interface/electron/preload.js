window.addEventListener("DOMContentLoaded", () => {
  console.log("Electron loaded");
});
