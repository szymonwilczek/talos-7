#ifndef ANIM_INVADERS_H
#define ANIM_INVADERS_H

void anim_invaders_init(void);
void anim_invaders_update(void);

#endif
