#ifndef ANIM_MATRIX_H
#define ANIM_MATRIX_H

void anim_matrix_init(void);
void anim_matrix_update(void);

#endif
