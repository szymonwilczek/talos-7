#ifndef ANIM_BREAKOUT_H
#define ANIM_BREAKOUT_H

void anim_breakout_init(void);
void anim_breakout_update(void);

#endif
