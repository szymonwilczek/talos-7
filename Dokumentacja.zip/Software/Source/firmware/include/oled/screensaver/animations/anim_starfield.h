#ifndef ANIM_STARFIELD_H
#define ANIM_STARFIELD_H

void anim_starfield_init(void);
void anim_starfield_update(void);

#endif
