#ifndef ANIM_BOUNCING_LOGO_H
#define ANIM_BOUNCING_LOGO_H

void anim_bouncing_logo_init(void);
void anim_bouncing_logo_update(void);

#endif
