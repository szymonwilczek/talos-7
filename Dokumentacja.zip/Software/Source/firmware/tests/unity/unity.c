/*
 * Unity Test Framework - source file
 */

#include "unity.h"

int Unity_TestsRun = 0;
int Unity_TestsFailed = 0;
int Unity_TestsIgnored = 0;
const char *Unity_CurrentTest = NULL;
